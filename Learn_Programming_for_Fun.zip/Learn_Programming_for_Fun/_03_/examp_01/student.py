name = "Jack"
age = 18
