

"""
if condition:  #  # if-block
    # Code to run if condition is True
else:             # else-block
    # Code to run if condition is False
"""
