
from datetime import date
current_date = date(year=1998, month=2, day=11)

format = current_date.strftime("%m %d %Y")
print(format)

'''
What happens if the following code is run?

Select the correct answer:
a. The code prints "04 21 2024" to the output.
b. The code prints "21 April 2024" to the output.
c. The code prints "April 21 24" to the output.
d. The code prints "April 21 2024" to the output.
e. The code prints nothing to the output.

The correct answer is a.
'''