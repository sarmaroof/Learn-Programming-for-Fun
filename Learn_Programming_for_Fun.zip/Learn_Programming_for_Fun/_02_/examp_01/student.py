name = "Emma"
age = 21

print(name)
print(age)