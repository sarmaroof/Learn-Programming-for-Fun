
freelancers = ["Edward", "Jeff", "Robert", "John", "Daniel"]

freelancers2 = freelancers.copy()
freelancers2.sort()

print(freelancers2[1], freelancers[1])

'''
What happens if the following code is run?

Select the correct answer:
a. The code prints "Jeff Jeff" to the output.
b. The code prints "Edward Daniel" to the output.
c. The code prints "Edward Jeff" to the output.
d. The code prints "Daniel Edward" to the output.
e. The code prints nothing to the output.

The correct answer is c.
'''