age = input("How old are you: ")
print("You are", age, "years old!")