

from random import choice
cards = ["Clubs", "Diamonds", "Hearts", "Spades"]
card_value = ["Ace", 2, 3, 4, 5, 6, 7, 8, 9, 10, "Jack", "Queen", "King"]
selected_card = choice(cards)
selected_card_value = choice(card_value)

print("Randomly selected card: ", selected_card_value,"of",selected_card)
