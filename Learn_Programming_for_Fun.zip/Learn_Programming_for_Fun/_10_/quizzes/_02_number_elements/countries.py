
# the keys are the countries and the values are the capitals
countries = {'United States':'Washington', 'Germany':'Berlin', 'France':'Paris', 'Spain':'Madrid'}

print(len(countries), end= " ")
countries["United Kingdom"] = "London"
countries["Brazil"] = "Brasília"
print(len(countries))


'''
What happens if the following code is run?

Select the correct answer:
a. The code prints "4 6" to the output.
b. The code prints "4 4" to the output.
c. The code prints "6" to the output.
d. The code prints "4" to the output.
e. The code prints nothing to the output.

The correct answer is a.
'''