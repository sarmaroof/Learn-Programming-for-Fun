condition1 = True
condition2 = False
condition3 = True

if condition1:  # if-block
    1+ 1  # code block 1 (runs if condition1 is True)
if condition2:  # if-block
    1 + 1  # code block 2 (runs if condition2 is True)
if condition3:  # if-block
    1 + 1  # code block 3 (runs if condition3 is True)
else:   # else-block
    2 + 2  # Code block 4 (runs only if ALL above `if` conditions are False)