colors = "red, blue, green, yellow, purple"
color = "yellow"
print(color in colors)