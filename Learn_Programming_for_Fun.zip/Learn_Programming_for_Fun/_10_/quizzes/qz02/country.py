
# the keys are the countries and the values are the capitals
countries = {'Japan':'Tokyo', 'Italy':'Ottawa', 'India':'Rome'}

print(countries['Italy'])

'''
What happens if the following code is run?

Select the correct answer:
a. The code prints "4" to the output.
b. The code prints "5" to the output.
c. The code prints "2" to the output.
d. The code prints "3" to the output.

The correct answer is d.

'''