x = 6
y = 3

print("x + y =", x + y)   # addition
print("x - y =", x - y)   # subtraction
print("x * y =", x * y)   # multiplication
print("x / y =", x / y)   # division