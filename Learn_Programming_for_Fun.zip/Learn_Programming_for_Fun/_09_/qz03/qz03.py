title = "Soft rain"

print(title[5:])    # 1
print(title[5:-1])  # 2
print(title[5:9])   # 3
print(title[5:8])   # 4
