# declare a list
names = ["Noah", "Amelia", "Olivia", "James", "Emma"]

names.sort()
print(names[0])

'''
What happens if the following code is run?

Select the correct answer:
a. The code prints "Noah" to the output.
b. The code prints "Amelia" to the output.
c. The code prints "James" to the output.
d. The code prints "Emma" to the output.

The correct answer is b.

'''