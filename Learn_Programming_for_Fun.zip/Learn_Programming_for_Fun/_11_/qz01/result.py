
def calculate(nr1, nr2, nr3):
    result = nr1 - nr2 + nr3
    return result

result = calculate(35, 20, 5)
print(result)

'''
What happens if the following code is run?
Select the correct answer:
a. The code prints "22" to the output.
b. The code prints "20" to the output.
c. The code prints "32" to the output.
d. The code prints "52" to the output.
e. The code prints nothing to the output.
The correct answer is c.
'''