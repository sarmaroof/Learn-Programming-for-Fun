quote = "Take the risk or lose the chance." # Einstein

print("risk" in quote)        # True "risk" is in the quote
print("and" in quote)         # False "we" is not in the quote
print("price" not in quote)   # True "price" is not in the quote