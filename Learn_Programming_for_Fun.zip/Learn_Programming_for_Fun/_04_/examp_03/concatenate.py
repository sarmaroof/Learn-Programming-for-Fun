firstname = "Charles "
lastname = "Darwin"

'''
You can concatenate the 
firstname and lastname values 
using the '+' operator.
'''
name = firstname + lastname

print(name)