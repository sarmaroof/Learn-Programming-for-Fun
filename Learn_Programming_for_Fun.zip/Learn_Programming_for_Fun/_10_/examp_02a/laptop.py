# Dictionary of laptop brands and their prices
laptops = {'Samsung': 2000, 'ASUS': 1800, 'Apple': 2400, 'Lenovo': 1300}

# Prompt user to enter a laptop brand
laptop = input("Enter the laptop brand: ")

# Retrieve and store the price of the entered laptop
price = laptops[laptop]

# Display the price
print("Price of", laptop, "is: $", price)