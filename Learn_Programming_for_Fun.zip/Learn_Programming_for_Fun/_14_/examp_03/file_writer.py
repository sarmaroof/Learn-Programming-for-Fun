
# you can choose another path

# linux_path_dir = "/home/sar/00_generated_map/MyFile.txt"

path_dir = "NewFile.txt"
file_writer = open(path_dir, "w")
quote1 = "Quote 1: If you want it, work for it. "
# writes the text to the file
file_writer.write(quote1)

file_writer = open(path_dir, "a")
quote2 = "Quote2: Grow through what you go through."
# appends the quote2 to the end of the file content.
file_writer.write(quote2)
# close the file
file_writer.close()