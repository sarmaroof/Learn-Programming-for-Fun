

# integers randrange(start included, stop excluded)
from random import randrange
random_nr = randrange(4, 8)
print(random_nr)

