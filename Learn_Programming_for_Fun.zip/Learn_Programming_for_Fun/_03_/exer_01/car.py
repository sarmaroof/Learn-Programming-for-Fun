brand = "BMW"
color = "Black"

print(brand)
print(color)