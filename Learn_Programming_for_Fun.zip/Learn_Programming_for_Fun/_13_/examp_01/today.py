

from datetime import date

today = date.today()  # Get current date
print("Today's date:", today)


