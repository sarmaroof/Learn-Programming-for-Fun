title = "Gold heart"
'''
 if the end position is empty, it indicates 
 reaching the end of the string.
'''

print (title[0:4])    # prints Gold
print(title[5:9])     # prints hear
print (title[5:])     # prints heart
print(title[5:10])    # prints heart
