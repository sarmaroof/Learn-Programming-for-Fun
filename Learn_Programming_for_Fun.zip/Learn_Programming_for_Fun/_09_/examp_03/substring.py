title = "Gold heart"

# starting from the beginning of the string

print(title[:4])    # prints Gold
print(title[0:4])   # prints Gold
print(title[:-6])   # prints Gold
print(title[-10:4]) # prints Gold

'''
If both the initial and final positions 
are empty, it implies the entire title.
'''

print(title[:])     # prints the whole title (Gold heart)
print (title[0:10]) # prints the whole title (Gold heart)