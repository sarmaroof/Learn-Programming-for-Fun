
names = ["Noah", "Amelia"]

names.insert(1, "Emma")

index = 0
while index < len(names):
   print(names[index])
   index += 1

'''

'''