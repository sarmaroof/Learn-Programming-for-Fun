
brand = "BMW"
print(brand)

