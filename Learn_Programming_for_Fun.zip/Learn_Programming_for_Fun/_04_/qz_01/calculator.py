nr1 = 6
nr2 = 3

print(nr1 * nr2)
print(nr1 / 2)