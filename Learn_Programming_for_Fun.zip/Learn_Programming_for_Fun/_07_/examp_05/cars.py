
# declare a list
cars = ["Audi", "Tesla", "Volvo", "BMW", "Toyota"]
# remove the element "Volvo" from the list
cars.remove("Volvo")

# display all the elements of the list
index = 0
while index < len(cars):
    print(cars[index])
    index += 1
