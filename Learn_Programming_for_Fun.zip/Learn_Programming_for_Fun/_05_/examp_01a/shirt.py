age = 20  # variable age

if age < 18:                          # if-block
    print("You receive two shirts!")  # body of if-block
else:                                 # else-block
    print("You receive one shirt.")   # body of else-block

print("The End")  # statement 1