nr1 = 3
nr2 = 4
nr3 = 5

print(nr1 < nr2 and nr3 != 5)
print(nr1 < nr2 or nr3 != 5)