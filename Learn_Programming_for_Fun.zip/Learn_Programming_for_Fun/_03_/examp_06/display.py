# declaring variables
name = "Vera"
age = 32
is_married = True
wage = 2340.55
# print texts with the variable values
print("Person's Data")
print("..............")
print("Name:    ", name)
print("Age:     ", age)
print("Married: ", is_married)
print("Wage:   $", wage)