

for number in range (8, 10):
    print(number, end = ' ')


'''
What happens if the following code is run?

Select the correct answer:
a. The code prints "8 9 10 " to the output.
b. The code prints "0 1 2 3 4 5 6 7 8 9 " to the output.
c. The code prints "7 8 9 " to the output.
d. The code prints "8 9 " to the output.
e. The code prints nothing to the output.

The correct answer is d.
'''