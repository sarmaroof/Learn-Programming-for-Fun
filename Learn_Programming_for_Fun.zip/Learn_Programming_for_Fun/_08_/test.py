import turtle

t = turtle.Turtle()

for _ in range(4):
    t.forward(100)   # Move forward 100 pixels
    t.right(90)      # Turn right 90 degrees

turtle.done()
