nr = 1
while nr < 5:                      # head of the loop
    print(nr) # body: statement 1
    nr += 1                        # body: statement 2
