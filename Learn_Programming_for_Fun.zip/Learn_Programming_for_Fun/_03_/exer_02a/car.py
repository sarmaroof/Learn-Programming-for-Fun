
print(brand)
brand = "BMW"
