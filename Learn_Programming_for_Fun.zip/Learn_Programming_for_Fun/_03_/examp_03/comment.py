# this is a single-line comment.

'''
this is a multi-line comment
this is a multi-line comment
this is a multi-line comment
'''
# declares color variable
color = "Red"
"""
this is a multi-line comment
this is a multi-line comment
this is a multi-line comment
"""
print(color)