# A list of popular fruits
fruits = ['Apple', 'Banana', 'Orange', 'Mango', 'Grapes']

# display elements of the list
print(fruits[0])  # prints Apple
print(fruits[1])  # prints Banana
print(fruits[2])  # prints Orange
print(fruits[3])  # prints Mango
print(fruits[4])  # prints Grapes