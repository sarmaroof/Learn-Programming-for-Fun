# Define a function to display company contact information
def company_contact():
    # Company contact details
    name = "Quantum"
    phone = "0033-939393"
    email = "emma@quantum.com"
    
    # Print formatted contact information
    print("Name:    ", name)
    print("Phone:   ", phone)
    print("Email:   ", email)
    print("------------")

# Call the function twice to demonstrate its usage
company_contact()  # First call
company_contact()  # Second call