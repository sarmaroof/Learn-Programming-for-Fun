grade = 7  # Student grade (1-10 scale)

if grade >= 9 and grade <= 10:
    print("The grade of", grade, "is Excellent")  # 9-10: Excellent
elif grade >= 7 and grade <= 8:
    print("The grade of", grade, "is Good")       # 7-8: Good
elif grade >= 5 and grade <= 6:
    print("The grade of", grade, "is Sufficient") # 5-6: Sufficient
elif grade >= 1 and grade <= 4:
    print("The grade of", grade, "is Insufficient") # 1-4: Insufficient
else:
    print("Invalid Grade")  # Handles numbers outside 1-10 range