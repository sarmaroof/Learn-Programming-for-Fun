x = 5
y = 9

x += 3
y -= 5

print(x, y)
