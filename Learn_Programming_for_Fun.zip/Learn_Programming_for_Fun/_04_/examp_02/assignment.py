nr1 = 5
nr2 = 4

nr1 += 3   # increments the value of nr1 by 3
print(nr1)  # prints nr1 which is 5 + 3 = 8

nr2 -= 2   # decrements the value of nr2 by 2
print(nr2) # prints nr2 which is 4 - 2 = 2