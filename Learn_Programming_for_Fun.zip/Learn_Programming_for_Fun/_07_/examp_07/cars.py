# declare a list
cars = ["Audi", "Tesla", "Volvo", "BMW", "Toyota"]

# the clear function removes all the elements of the list
cars.clear()

# display all the elements of the list
index = 0
while index < len(cars):
    print(cars[index])
    index += 1