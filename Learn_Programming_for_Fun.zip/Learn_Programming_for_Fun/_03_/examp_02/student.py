
# this allocates memory to store the name
name = "Jack"
# this allocates memory to store the age
age = 18

# prints the name
print(name)
# prints the age
print(age)