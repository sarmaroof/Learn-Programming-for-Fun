condition1 = True
condition2 = False
condition3 = True

if condition1:        # 1st condition checked
    1+1# Runs only if condition1 is True
elif condition2:      # Checked if condition1 is False
    1+1# Runs only if condition1=False AND condition2=True
elif condition3:      # Checked if all previous conditions are False
    1+1# Runs only if condition1=False, condition2=False, AND condition3=True
else:                # Optional catch-all
    1+1# Runs only if ALL conditions above are False