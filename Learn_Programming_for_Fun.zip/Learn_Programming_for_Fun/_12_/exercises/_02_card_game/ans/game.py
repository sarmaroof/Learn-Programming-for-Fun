from random import choice

cards = ["clubs", "Diamonds", "Hearts", "Spades"]
card_values = [2, 3, 4, 5, 6, 7, 8, 9,  10, 'Jack', 'Queen', 'King', 'Ace']
# select a random card
random_card = choice(cards)
# select a random card value
random_card_value = choice(card_values)

print("Your selected card is: ", random_card_value, "of", random_card)



