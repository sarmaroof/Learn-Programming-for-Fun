
names = ["Noah", "Amelia", "Olivia", "James", "Emma"]

names.pop(4)

index = 0
while index < len(names):
   print(names[index])
   index += 1

'''

'''