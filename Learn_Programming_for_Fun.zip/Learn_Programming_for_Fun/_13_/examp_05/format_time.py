

from datetime import time
time = time(hour=15, minute=8, second=23)


format1 = time.strftime("%I:%M:%S  %p")
# PM or AM
print("Format 1: ", format1)
# 24 hours
format2 = time.strftime("%H:%M:%S")
print("Format 2: ", format2)
