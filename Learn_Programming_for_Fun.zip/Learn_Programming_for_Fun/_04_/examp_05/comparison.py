x = 4
y = 4
z = 5

print("Is x equal to y: ", x == y)                # True
print("Is x unequal to y: ", x != y)              # False
print("Is z larger than x: ", z > x)              # True
print("Is x larger than or equal to y: ", x >= y) # True
print("Is z smaller or equal to y: ", z <= y)     # False

