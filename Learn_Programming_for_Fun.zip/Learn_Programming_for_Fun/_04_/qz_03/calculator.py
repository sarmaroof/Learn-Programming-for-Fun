x = 5
y = 6

print(x == y)
print(y >= x)
print(y < 4)