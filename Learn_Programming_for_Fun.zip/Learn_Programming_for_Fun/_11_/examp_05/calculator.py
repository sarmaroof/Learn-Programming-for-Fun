def sum(number1, number2):
    # calculates and returns the sum of two numbers.
    sum = number1 + number2
    return sum

# get user input for two numbers
nr1 = input("Enter first number: ")
nr2 = input("Enter second number: ")

# convert inputs from strings to integers
nr1 = int(nr1)
nr2 = int(nr2)

# calculate and store the sum
result = sum(nr1, nr2)

# display the result
print("The sum is: ", result)