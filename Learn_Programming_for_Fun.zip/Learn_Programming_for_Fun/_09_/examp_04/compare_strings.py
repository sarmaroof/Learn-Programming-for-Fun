# returns true
print("Paris" == "Paris")
# returns false, Python is case-sensitive
print("USA" == "USa")
# as explained earlier, '!=' checks for inequality.
# returns True because the values are not equal.
print("China" != "Ch")
# returns false, the left side lacks space between the words.
print("Soft" +"music" == "Soft music")
# returns true, space in the end of True
print("True " +"story" == "True story")
# returns true, space in the beginning of story
print("True" +" story" == "True story")