

from random import randrange
random_nr = randrange(0, 0)
print(random_nr)


'''
Which values should be passed to the randrage function
to select a random number from 10 to 20? Both 10 and 20 are inclusive.

Select the correct answer:
a. The values should be randrange(9, 21).
b. The values should be randrage(10, 21).
c. The values should be randrage(10, 20).
d. The values should be randrage(9, 20).
e. The code prints nothing to the output.

The correct answer is b.


'''