
from datetime import date
# the order of the date is year, month, and day.
birthdate = date(2004, 10, 24)
print("Birthdate: ", birthdate)


