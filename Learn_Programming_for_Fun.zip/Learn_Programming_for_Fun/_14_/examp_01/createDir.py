
# linux_path_dir = "/home/sar/_new_map/MyFile.txt"

import os
# you can choose another path
path_dir = "_new_map"
os.mkdir(path_dir)

