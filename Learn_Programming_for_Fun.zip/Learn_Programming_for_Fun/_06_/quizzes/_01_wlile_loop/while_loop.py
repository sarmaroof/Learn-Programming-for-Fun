id = 4

while id < 8:
    print(id)    # statement 1
    id += 1      # statement 2

'''
What happens if the following code is run?

Select the correct answer:
a. The code prints "1 2 3 4 " to the output.
b. The code prints "10 " to the output.
c. The code prints "6 7 8 9 " to the output.
d. The code prints "6 7 8 " to the output.
e. The code prints nothing to the output.

The correct answer is c.
'''



