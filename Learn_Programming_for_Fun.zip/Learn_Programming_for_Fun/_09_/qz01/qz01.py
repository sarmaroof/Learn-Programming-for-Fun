title = "DEEP BLUE"

print(title[7])