# declare a list
cars = ["Audi", "Tesla", "Volvo", "BMW", "Toyota"]

# add  "Fort" at the third position in the list. Element indexes start with “0”
cars.insert(3, "Fort")

# display all the elements of the list
index = 0
while index < len(cars):
    print(cars[index])
    index += 1
