

from random import choice
cards = ["Clubs", "Diamonds", "Hearts", "Spades"]
selected_card = choice(cards)

print("Randomly selected card: ", selected_card)
