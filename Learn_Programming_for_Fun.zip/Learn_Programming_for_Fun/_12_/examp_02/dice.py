

# a dice range is from one to six
from random import randrange
random_nr = randrange(1, 7)
print(random_nr)

