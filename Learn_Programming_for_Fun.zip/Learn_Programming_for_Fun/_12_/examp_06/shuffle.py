

from random import shuffle
cards = ["Clubs", "Diamonds", "Hearts", "Spades"] # 1. Make card list
# change the cards order randomly
shuffle(cards)                    # 2. Shuffle the cards
print("Shuffled deck:", cards)    # 3. Show mixed cards

