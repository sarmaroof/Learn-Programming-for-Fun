x = 5
y = 8

print(x < y and x == 5)         # True
print(x < y and x == 6)         # False
print(x > y or x == 5)          # True
print(x < y or x == 7)          # True
