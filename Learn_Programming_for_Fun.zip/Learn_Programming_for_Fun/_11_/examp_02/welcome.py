
def quote():
    print("Welcome to New York")

# call (invoke) the function
quote()