# declaring variables
name = "George"
age = 22
is_married = False
wage = 2300.4557

# declare new variables for the types
nameType = type(name)
ageType = type(age)
isMariedType = type(is_married)
wageType = type(wage)

# display the variable types
print(nameType)
print(ageType)
print(isMariedType)
print(wageType)