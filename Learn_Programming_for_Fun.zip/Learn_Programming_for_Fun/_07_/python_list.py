# A list of popular fruits
fruits = ['Apple', 'Banana', 'Orange', 'Mango', 'Grapes']