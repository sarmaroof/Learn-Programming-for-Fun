name = "Jack"
print(name)


