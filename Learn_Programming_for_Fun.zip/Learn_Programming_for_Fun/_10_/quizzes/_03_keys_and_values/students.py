
# the keys are the names and the values are the ages
students = {"Edward":22, "Jack":34, "George":22}

for(key, value) in students.items():
    print(key, ':', value)


'''
What happens if the following code is run?

Select the correct answer:
a. The code prints only the student names to the output.
b. The code prints only the student ages to the output.
c. The code prints the names and the ages to the output.
d. The code prints only the name Edward and his age to the output.
e. The code prints nothing to the output.

The correct answer is c.
'''