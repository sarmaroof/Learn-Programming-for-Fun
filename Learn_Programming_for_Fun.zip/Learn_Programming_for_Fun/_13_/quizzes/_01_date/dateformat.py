from datetime import date
current_date = date(year=2021, month=4, day=14)
format = current_date.strftime("%b %d %y")
print(format)
'''
What happens if the following code is run?

Select the correct answer:
a. The code prints "2024 july 10" to the output.
b. The code prints "10 July 2024" to the output.
c. The code prints "07 10 24" to the output.
d. The code prints "July 10 2024" to the output.
e. The code prints nothing to the output.

The correct answer is d.

'''