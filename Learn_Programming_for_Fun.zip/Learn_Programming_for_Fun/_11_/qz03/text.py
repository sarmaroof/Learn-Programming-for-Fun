
def letters(ltr1, ltr2):
    text = ltr1 + ltr2 + ltr1
    return text

print(letters('Q', 'N'))

'''
What happens if the following code is run?

Select the correct answer:
a. The code prints "STZ" to the output.
b. The code prints "ZST" to the output.
c. The code prints "ZTS" to the output.
d. The code prints "ZSTZ" to the output.
e. The code prints nothing to the output.

The correct answer is d.
'''