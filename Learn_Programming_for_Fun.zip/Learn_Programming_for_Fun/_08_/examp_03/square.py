
symbol = input("Enter a character: ")
print("====================")
# The symbol multiplying by 20 means print it 20 times
print(symbol * 20)
print(symbol * 20)
print(symbol * 20)
print(symbol * 20)
print(symbol * 20)
print(symbol * 20)
