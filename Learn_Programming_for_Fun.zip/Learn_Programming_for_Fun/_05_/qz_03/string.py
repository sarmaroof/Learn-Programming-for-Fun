nr = 9
display = ""

if nr == 9:
    display += "X "
if nr > 5:
    display += "Y "
if nr > 9:
    display += "Z "

print(display)
