title = "DEEP BLUE"

print(title[5:8])