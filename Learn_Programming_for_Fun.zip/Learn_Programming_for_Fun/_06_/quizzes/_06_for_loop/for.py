
for number in range (5):
    print(number, end = ' ')

'''
Select the correct answer:
a. The code prints "0 1 2 3 " to the output.
b. The code prints "0 1 2 " to the output.
c. The code prints "0 1 2 3 4  " to the output.
d. The code prints "0 1 2 3 4 5 " to the output.
e. The code prints nothing to the output.

The correct answer is c.

'''