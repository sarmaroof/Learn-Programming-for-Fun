salary = 3000
is_certified = False
experience = 5
age = 31

if is_certified:
    salary += 300   # Add $300 if the candidate is certified
if experience >= 5:
    salary += 1000  # Add $1000 if they have 5+ years of experience
if age > 30:
    salary += 200   # Add $200 if they are over 30 years old

# Print the final salary after applying all conditions
print("The candidate receives: $", salary)