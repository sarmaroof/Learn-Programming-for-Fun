number1 = 10
number2 = 20

if number1 < 18:
    print(number2)
if number2 > 15:
    print("N")
else:
    print("S")
