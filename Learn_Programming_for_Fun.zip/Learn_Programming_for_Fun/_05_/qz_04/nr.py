nr = 7
show = 4

if nr == 8:
    show += 3
if nr > 5:
    show += 5
if nr >= 7:
    show += 2

print(show)
