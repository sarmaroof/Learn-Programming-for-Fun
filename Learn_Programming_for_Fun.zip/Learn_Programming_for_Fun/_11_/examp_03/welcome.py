
def quote(city):
    print("Welcome to", city)

# call (invoke) the function
quote("London")
