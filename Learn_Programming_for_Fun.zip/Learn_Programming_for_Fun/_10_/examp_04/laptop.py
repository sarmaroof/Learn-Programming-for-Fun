# the keys are the laptop brands and the values are the prices
laptops = {'Samsung': 2000, 'ASUS': 1800, 'Apple': 2400, 'Lenovo': 1300}

# add HP with price 1200 to the dictionary
laptops["HP"] = 1200

# print the dictionary
print(laptops)