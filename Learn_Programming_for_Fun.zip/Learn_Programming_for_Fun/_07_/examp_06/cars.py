# declare a list
cars = ["Audi", "Tesla", "Volvo", "BMW", "Toyota"]
# remove the element "BMW" from the list
cars.pop(3)

# display all the elements of the list
index = 0
while index < len(cars):
    print(cars[index])
    index += 1
