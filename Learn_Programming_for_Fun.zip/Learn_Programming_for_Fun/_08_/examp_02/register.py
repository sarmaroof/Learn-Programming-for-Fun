
'''
assign the values that the user enters to the
variables first name, last name, age, and email
'''

first_name = input("Enter your first name: ")
last_name = input("Enter your last name: ")
age = input("Enter your age:   ")
email = input("Enter your email: ")
print("----------------------------")
print("Name:   ", first_name, last_name)
print("Age:    ", age)
print("Email: ", email)