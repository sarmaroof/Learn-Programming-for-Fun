nr = 7
show = 4

if nr == 8:
    show += 3
elif nr > 5:
    show += 5
elif nr >= 7:
    show += 2

print(show)
