
def net_wage(gross_salary, taxrate):
    tax_amount = (taxrate / 100) * gross_salary
    net_salary = gross_salary - tax_amount
    return net_salary

gross_wage = input("Enter your gross salary: $")
gross_wage = float(gross_wage)
country_taxrate = input("Enter the tax rate in your country: %")
taxrate = int(country_taxrate)
net_wage = net_wage(gross_wage, taxrate)

# print the net wage rounded to the nearest decimals.
print("Net wage: $%.2f" % net_wage)

