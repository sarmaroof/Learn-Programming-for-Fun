# A list of popular fruits
fruits = ['Apple', 'Banana', 'Orange', 'Mango', 'Grapes']

# display all the list elements
index = 0
while index < 5:
    print(fruits[index])
    index += 1