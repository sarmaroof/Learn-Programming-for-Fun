
# linux_path_dir = "/home/sar/00_generated_map/MyFile.txt"
import os
path_dir = "NewFile.txt"

# create an empty text file called MyFile.txt
file = open(path_dir, "x")
print("The file is created.")
file.close()
