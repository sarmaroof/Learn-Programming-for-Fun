price = 20

if price < 18:
    print("X")
else:
    print("Y")
