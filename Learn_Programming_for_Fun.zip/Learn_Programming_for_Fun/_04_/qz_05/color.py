colors = "blue, red, green, black, white, yellow"

print("YELLOW" in colors)
print("red" in colors)