

# a dice range is from one to six
from random import randrange
dice1 = randrange(1, 7)
dice2 = randrange(1, 7)
print(dice1, ",", dice2)

