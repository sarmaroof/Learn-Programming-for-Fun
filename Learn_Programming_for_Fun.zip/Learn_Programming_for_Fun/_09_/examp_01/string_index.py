title = "Gold heart"

print(title[0])     # prints G
print (title[-10])  # prints G
print (title[3])    # prints d
print(title[-7])    # prints d
print (title[8])    # prints r
print (title[-2])   # prints r