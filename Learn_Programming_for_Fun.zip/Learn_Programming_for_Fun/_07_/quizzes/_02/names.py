
names = ["Noah", "Amelia", "Olivia", "James", "Emma"]

index = 0
while index < len(names):
    if index == 2:
        print(names[index])
    index += 1


'''
What happens if the following code is run?

Select the correct answer:
a. The code prints "Noah" to the output.
b. The code prints "Amelia" to the output.
c. The code prints "Olivia" to the output.
d. The code prints "Emma " to the output.

The correct answer is c.
'''