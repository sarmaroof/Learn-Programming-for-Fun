brand = "Volvo"
color = "Red"
model_year = 2024

print(model_year)