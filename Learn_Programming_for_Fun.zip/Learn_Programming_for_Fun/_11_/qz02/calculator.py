
def calculator(nr1, nr2, nr3):
    result = (nr1 * nr2) - nr3
    return result

print(calculator(4, 3, 4))

'''
What happens if the following code is run?

Select the correct answer:
a. The code prints "17" to the output.
b. The code prints "12" to the output.
c. The code prints "13" to the output.
d. The code prints "11" to the output.
e. The code prints nothing to the output.

The correct answer is a.

'''