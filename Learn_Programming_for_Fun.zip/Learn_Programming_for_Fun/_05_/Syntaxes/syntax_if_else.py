condition = True

if condition:  # if-block
    1+ 1
    # the if-body
    # Code to run if condition is True
else:   # else-block
    2 + 2
    # the else-body
    # Code to run if condition is False