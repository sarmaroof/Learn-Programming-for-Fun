# the keys are the laptop brands and the values are the prices
laptops = {'Samsung': 2000, 'ASUS': 1800, 'Apple': 2400, 'Lenovo': 1300}

# iterating over the key:vlaue pairs using .items() method
for(key, value) in laptops.items():
    print(key, ': $', value)