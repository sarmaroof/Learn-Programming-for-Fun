


nr = 1
while nr < 6:
    nr += 1
    # if the rest = 0 as a result of dividing the nr by 2.
    if nr % 2 == 0:
        continue
    else:
        print(nr, end=' ')


'''
Select the correct answer:
a. The code prints "1 2 3 4 5 6  " to the output.
b. The code prints "3 4 5  " to the output.
c. The code prints "3 5 " to the output.
d. The code prints "2 3 " to the output.
e. The code prints nothing to the output.

The correct answer is c.
'''