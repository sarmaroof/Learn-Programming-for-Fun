
# company info
name = "Quantum"
phone = "0033-939393"
email = "emma@quantum.com"


print("Name:    ", name)
print("Phone:   ", phone)
print("Email:   ", email)



