
def student(name, age):
    print("----------------------")
    print("Name: ", name)
    print("Age:  ", age)

username = input("Enter your name: ")
userage = input("Enter your age: ")
# call (invoke) the function
student(username, userage)