firstname = "Charles "
lastname = "Darwin"

'''
You can concatenate the 
firstname and lastname values 
using the '+=' operator.
'''
firstname += lastname
# the lastname is concatenated to firstname
print(firstname)