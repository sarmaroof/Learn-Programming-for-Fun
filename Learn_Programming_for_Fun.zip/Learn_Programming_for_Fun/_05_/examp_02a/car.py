price = 6000
discount = 500

if price >= 5000:
    print("Price of the car is: $", price - discount)
else:
    print("Price of the car is: $", price)

print("Thank you for your purchase!")