price = 9000
discount = 1000

if price >= 7000:
    print("Price of the car is: $", price - discount)
else:
    print("Price of the car is: $", price)

print("Thank you for your purchase!")