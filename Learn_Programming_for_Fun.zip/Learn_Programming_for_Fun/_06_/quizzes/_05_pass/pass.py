nr = 0
while nr < 10:
   if nr >= 5 or nr < 3:
       pass
   else:
       print(nr, end = ' ')
   nr += 1

'''
What happens if the following code is run?

Select the correct answer:
a. The code prints "0 1 2 3 4 5  " to the output.
b. The code prints "3 4 5  " to the output.
c. The code prints "3 4 " to the output.
d. The code prints "2 3 4 " to the output.
e. The code prints nothing to the output.

The correct answer is c.
'''