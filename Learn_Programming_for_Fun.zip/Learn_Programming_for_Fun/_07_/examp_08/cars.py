# declare a list
cars = ["Audi", "Tesla", "Volvo", "BMW", "Toyota"]

# Sort the list alphabetically
cars.sort()
# display all the elements of the list
index = 0
while index < len(cars):
    print(cars[index])
    index += 1