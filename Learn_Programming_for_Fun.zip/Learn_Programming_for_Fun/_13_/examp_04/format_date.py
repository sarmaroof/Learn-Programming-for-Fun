

from datetime import date
current_date = date(year=2025, month=5, day=7)

format1 = current_date.strftime("%B %d %Y")
print("Format 1: ", format1)

format3 = current_date.strftime("%a-%m/%d/%Y")
print("Format 3: ", format3)

format2 = current_date.strftime("%A-%d-%b-%Y")
print("Format 2: ", format2)