 # a comma-separated string of city names
cities = "Rome, Tokyo, Miami, London, Berlin, Madrid"
# display the current list of cities to the user
print("Current list:", cities)
# prompt the user to input a city name
city = input("Enter a city name: ")

# check if the city entered by the user exists in the cities list.
print("Is it on the list?", city in cities)