# the keys are the laptop brands and the values are the prices
laptops = {'Samsung': 2000, 'ASUS': 1800, 'Apple': 2400, 'Lenovo': 1300}

# remove ASUS by using the function pop
laptops.pop("ASUS")
# removing Lenovo by using the del keyword
del laptops["Lenovo"]

# print the dictionary
print(laptops)