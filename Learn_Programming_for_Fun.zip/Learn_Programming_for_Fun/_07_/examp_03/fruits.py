# A list of fruits
fruits = ['Apple', 'Banana', 'Orange', 'Mango', 'Grapes']

# append() adds an element at the end of the list
fruits.append("Watermelon")
# display all the list elements
index = 0
while index < len(fruits):
    print(fruits[index])
    index += 1


'''
fruits = ['Apple', 'Banana', 'Orange', 'Mango', 'Strawberry',
          'Grapes', 'Pineapple', 'Watermelon', 'Blueberry', 'Peach']
'''
