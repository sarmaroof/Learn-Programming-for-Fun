
def largest(nr1, nr2, nr3):
    if nr1 > nr2 and nr1 > nr3:
       print("The largest is:", nr1)
    elif nr2 > nr1 and nr2 > nr3:
        print("The largest is:", nr2)
    elif nr3 > nr1 and nr3 > nr2:
        print("The largest is:", nr3)
    else:
        print("Please enter unique numbers")
# ask the user to enter three numbers, one at a time
nr1 = input("Enter the first number: ")
nr2 = input("Enter the second number: ")
nr3 = input("Enter the third number: ")
# convert the numbers to integers.
nr1 = int(nr1)
nr2 = int(nr2)
nr3 = int(nr3)
# invoke the function by entering the user's numbers.
largest(nr1, nr2, nr3)

