
from random import shuffle
names = ["Emma", "David", "Jack", "George", "Ronald", "Vera", "Bruce"]

shuffle(names)

print("The names randomly: \n",names)

print("The winner of one million dollars is:", names[0])
print("The winner of 500 thousand dollars is:", names[1])
print("The winner of 100 thousand dollars is:", names[2])