
# today.py - Display current date in US format
from datetime import date

# Get today's date and format it as "Month Day, Year"
current_date = date.today()
print("Today's date:", current_date.strftime("%B %d, %Y"))




