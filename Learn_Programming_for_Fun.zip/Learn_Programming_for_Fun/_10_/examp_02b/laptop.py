# Dictionary of laptop brands and their prices
laptops = {'Samsung': 2000, 'ASUS': 1800, 'Apple': 2400, 'Lenovo': 1300}

number_laptops = len(laptops)

print("Number laptops: ", number_laptops)