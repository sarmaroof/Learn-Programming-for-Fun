
from random import shuffle
names = ["Emma", "David", "Jack", "George", "Ronald", "Vera", "Bruce"]

# add the rest of your code here.